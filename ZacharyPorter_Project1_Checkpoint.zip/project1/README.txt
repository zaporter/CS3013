// RESOURCES CONSULTED:
// https://ia.wpi.edu/cs3013-walls/resources.php?page=show_project&id=6
// man system
// man execl
// man fork
// man waitpid
// http://www.cplusplus.com/reference/cstdio/sprintf/
//https://stackoverflow.com/questions/5769734/what-are-the-different-versions-of-exec-used-for-in-c-and-c
https://gist.github.com/tkuchiki/4b77005cc64426b28c3d
man /usr/bin/time

https://stackoverflow.com/questions/13274786/how-to-share-memory-between-process-fork
https://askubuntu.com/questions/385528/how-to-increment-a-variable-in-bash
https://stackoverflow.com/questions/6958689/running-multiple-commands-with-xargs/6958957#6958957

man cut

